﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Runtime.Intrinsics.Arm;
using System.Threading.Tasks;
using System.Web;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;
using PSR_Add_Document.Models;
using System.Net.Http;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using NuGet.Protocol;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using System.IO;
using SixLabors.ImageSharp;
using SixLabors.ImageSharp.Processing;
using SixLabors.ImageSharp.Formats.Jpeg;
using PdfSharpCore.Pdf;
using PdfSharpCore.Drawing;
using PdfSharpCore.Pdf.IO;

namespace PSR_Add_Document.Controllers
{
    public class CustomersController : Controller
    {
        private readonly CustomerDbContext _context;
        private readonly IConfiguration _configuration;
        private IWebHostEnvironment environment;

        // SessionCustomer 

        public const string SessionAccountNo = "SessionAccountNo";
        public const string SessionCustomerName = "SessionCustomerName";
        public const string SessionCustomerId = "SessionCustomerId";

        public CustomersController(CustomerDbContext context, IConfiguration configuration, IWebHostEnvironment environment)
        {
            _context = context;
            _configuration = configuration;
            this.environment = environment;
        }

        // GET: Customers
        public async Task<IActionResult> Index()
        {
            return _context.Customers != null ?
                        View(await _context.Customers.ToListAsync()) :
                        Problem("Entity set 'CustomerDbContext.Customers'  is null.");

        }

        // GET: Customers/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: Customers/Create

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB,Email")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                _context.Add(customer);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }

        // GET: Customers/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers.FindAsync(id);
            if (customer == null)
            {
                return NotFound();
            }
            return View(customer);
        }


        // POST: Customers/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerId,CustomerName,AccountNumber,Address,MobileNumber,Gender,Brn,DOB")] Customer customer)
        {
            if (id != customer.CustomerId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(customer);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CustomerExists(customer.CustomerId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(customer);
        }


        // GET: Customers/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }

            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer);
        }


        // POST: Customers/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Customers == null)
            {
                return Problem("Entity set 'CustomerDbContext.Customers'  is null.");
            }
            var customer = await _context.Customers.FindAsync(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CustomerExists(int id)
        {
            return (_context.Customers?.Any(e => e.CustomerId == id)).GetValueOrDefault();
        }



        //Otp add page

        public IActionResult OTP()
        {

            return View();
        }


        public async Task<IActionResult> Login(int? id, Customer model)
        {
            if (id == null || _context.Customers == null)
            {
                return NotFound();
            }
            var customer = await _context.Customers
                .FirstOrDefaultAsync(m => m.CustomerId == id);
            if (customer == null)
            {
                return NotFound();
            }
            HttpContext.Session.SetString(SessionAccountNo, customer.AccountNumber);
            HttpContext.Session.SetString(SessionCustomerName, customer.CustomerName);
            HttpContext.Session.SetInt32(SessionCustomerId, customer.CustomerId);

            return View(customer);

        }


        private bool verifyOtp(string enterdOtp, string generateOtp)
        {
            return enterdOtp.Equals(generateOtp);
        }




        [HttpPost]
        public IActionResult SubmitOtp([FromForm] int finalDigit)
        {
            int a = Convert.ToInt32(TempData["otp"]);
            if (finalDigit == null)
            {
                return NoContent();
            }

            else if ((DateTime.Now - Convert.ToDateTime(TempData["timestamp"])).TotalMinutes > 30)
            {
                return BadRequest("OTP Timedout");
            }
            else if (finalDigit.ToString() == Convert.ToString(a))
            {
                return Ok("OTP Accepted");
            }
            else
            {
                return BadRequest("Please Enter Valid OTP");
            }
        }


        private string GenerateOTP()
        {
            const int otpLength = 4;
            const string characters = "0123456789";
            var random = new Random();
            var otp = new char[otpLength];

            for (int i = 0; i < otpLength; i++)
            {
                otp[i] = characters[random.Next(characters.Length)];
            }

            return new string(otp);
        }



        [HttpPost]
        public IActionResult VerifyOTP(OtpVerificationOptions model)
        {
            if (ModelState.IsValid)
            {
                if (TempData.TryGetValue("OTP", out object otp) &&
                    TempData.TryGetValue("MobileNumber", out object mobileNumber) &&
                    otp.ToString() == model.OTP && mobileNumber.ToString() == model.MobileNumber)
                {
                    TempData.Remove("OTP");
                    TempData.Remove("MobileNumber");

                    ViewBag.SuccessMessage = "OTP verification successful!";
                    return View();
                }

                ModelState.AddModelError("", "Invalid OTP");
            }
            return View(/*model*/);
        }

        [HttpGet]
        public IActionResult VerifyOTP()
        {
            if (TempData.TryGetValue("MobileNumber", out object mobileNumber))
            {
                TempData.Keep("MobileNumber");
                return View(new Customer { MobileNumber = mobileNumber.ToString() });
            }

            return View();
            //return RedirectToAction("Index");
        }



        public IActionResult ViewDocuments()
        {
            var documents = _context.CustomerDocuments.ToList(); // Fetch the documents from the database

            return View(documents);
        }

        public IActionResult AddDocument()
        {
            VMCustomerDocument objVMCustomerDocument = new VMCustomerDocument();

            objVMCustomerDocument.AccountNumber = HttpContext.Session.GetString(SessionAccountNo);
            objVMCustomerDocument.CustomerName = HttpContext.Session.GetString(SessionCustomerName);
            objVMCustomerDocument.CustomerId = HttpContext.Session.GetInt32(SessionCustomerId) ?? 0;

            ViewBag.AccountNumber = objVMCustomerDocument.AccountNumber;
            ViewBag.CustomerName = objVMCustomerDocument.CustomerName;
            ViewBag.CustomerId = objVMCustomerDocument.CustomerId;

            return View(objVMCustomerDocument);
        }

        //========================================================================
        //pdf and image compress


        //[HttpPost]
        //public IActionResult AddDocument(VMCustomerDocument model)
        //{
        //    // Check if a file is uploaded
        //    if (model.Document != null && model.Document.Length > 0)
        //    {
        //        string webRoot = environment.WebRootPath;
        //        string folder = "Documents"; // Change the folder name as per your requirement

        //        // Generate a unique file name
        //        string fileName = Guid.NewGuid().ToString();

        //        // Get the file extension
        //        string fileExtension = Path.GetExtension(model.Document.FileName);

        //        // Determine the file path based on the file extension
        //        string fileToWrite;
        //        string newFilePath;

        //        if (fileExtension.ToLower() == ".pdf")
        //        {
        //            fileToWrite = Path.Combine(webRoot, folder, fileName + fileExtension);
        //            newFilePath = Path.Combine(folder, fileName + fileExtension);

        //            // Check PDF file size (100 KB limit)
        //            if (model.Document.Length > 100 * 1024)
        //            {
        //                // Perform PDF compression
        //                CompressPdf(model.Document, fileToWrite, 100 * 1024);
        //            }
        //            else
        //            {
        //                using (var stream = new FileStream(fileToWrite, FileMode.Create))
        //                {
        //                    model.Document.CopyTo(stream);
        //                }
        //            }
        //        }
        //        else if (IsImageFileExtension(fileExtension.ToLower()))
        //        {
        //            fileToWrite = Path.Combine(webRoot, folder, "Images", fileName + fileExtension);
        //            newFilePath = Path.Combine("Images", fileName + fileExtension);

        //            // Perform image compression
        //            CompressImage(model.Document, fileToWrite, 50 * 1024);
        //        }
        //        else
        //        {
        //            // Invalid file type, handle accordingly (e.g., show an error message)
        //            return BadRequest("Invalid file type. Only PDF and image files are allowed.");
        //        }

        //        var customerDocument = new CustomerDocument
        //        {
        //            CustomerId = model.CustomerId,
        //            CustomerName = HttpContext.Session.GetString(SessionCustomerName),
        //            AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
        //            TinNumber = model.TinNumber,
        //            AssesmentYear = model.AssesmentYear,
        //            Reference = model.Reference,
        //            RefNumber = model.RefNumber,
        //            Document = newFilePath,
        //            DocumentPath = newFilePath
        //        };

        //        _context.CustomerDocuments.Add(customerDocument);
        //        _context.SaveChanges();

        //        return RedirectToAction("ViewDocuments");
        //    }

        //    // No file uploaded, handle accordingly (e.g., show an error message)
        //    return BadRequest("No file uploaded.");
        //}

        //private void CompressImage(IFormFile imageFile, string outputPath, int targetSizeInBytes)
        //{
        //    using (var image = Image.Load(imageFile.OpenReadStream()))
        //    {
        //        // Calculate the compression ratio
        //        double compressionRatio = (double)targetSizeInBytes / imageFile.Length;

        //        // Perform image compression
        //        image.Mutate(x => x.Resize(new ResizeOptions
        //        {
        //            Size = new Size((int)(image.Width * compressionRatio), (int)(image.Height * compressionRatio)),
        //            Mode = ResizeMode.Max
        //        }));

        //        // Save the compressed image to the output path
        //        using (var outputStream = new FileStream(outputPath, FileMode.Create))
        //        {
        //            image.Save(outputStream, new JpegEncoder { Quality = 75 });
        //        }
        //    }
        //}
        //private bool IsImageFileExtension(string fileExtension)
        //{
        //    string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif" }; // Add more image file extensions if needed

        //    return imageExtensions.Contains(fileExtension);
        //}


        //private void CompressPdf(IFormFile pdfFile, string outputPath, int targetSizeInBytes)
        //{
        //    using (var document = PdfReader.Open(pdfFile.OpenReadStream(), PdfDocumentOpenMode.Import))
        //    {
        //        // Create a new PDF document for compression
        //        var compressedDocument = new PdfDocument();

        //        // Copy each page from the original document to the compressed document
        //        foreach (var page in document.Pages)
        //        {
        //            var compressedPage = compressedDocument.AddPage();
        //            using (var gfx = XGraphics.FromPdfPage(compressedPage))
        //            {
        //                // Copy the content of the original page to the compressed page
        //                gfx.DrawPdfPage(gfx, page);
        //            }
        //        }

        //        // Save the compressed PDF document to the output path
        //        using (var outputStream = new FileStream(outputPath, FileMode.Create))
        //        {
        //            compressedDocument.Save(outputStream);
        //        }
        //    }
        //}

        //=========================================================


        //==========================================
        //

        [HttpPost]
        public IActionResult AddDocument(VMCustomerDocument model)
        {
            // Check if a file is uploaded
            if (model.Document != null && model.Document.Length > 0)
            {
                string webRoot = environment.WebRootPath;
                string folder = "Images"; // Change the folder name as per your requirement

                // Generate a unique file name
                string fileName = Guid.NewGuid().ToString();

                // Get the file extension
                string fileExtension = Path.GetExtension(model.Document.FileName);

                // Determine the file path based on the file extension
                string fileToWrite;
                string newFilePath;

                if (fileExtension.ToLower() == ".pdf")
                {
                    // Check PDF file size (200 KB limit)
                    if (model.Document.Length > 200 * 1024)
                    {
                        TempData["ErrorMessage"] = "Invalid file size. PDF files should be up to 200 KB.";
                        return View();
                        //return BadRequest("Invalid file size. PDF files should be up to 200 KB.");
                    }

                    fileToWrite = Path.Combine(webRoot, folder, fileName + fileExtension);
                    newFilePath = Path.Combine(folder, fileName + fileExtension);
                }
                else if (IsImageFileExtension(fileExtension.ToLower()))
                {
                    // Check image file size (100 KB limit)
                    if (model.Document.Length > 100 * 1024)
                    {
                        TempData["ErrorMessage"] = "Invalid file size. Image files should be up to 100 KB.";
                        return View();
                        //return BadRequest("Invalid file size. Image files should be up to 100 KB.");
                    }

                    fileToWrite = Path.Combine(webRoot, folder, "Images", fileName + fileExtension);
                    newFilePath = Path.Combine("Images", fileName + fileExtension);
                }
                else
                {
                    // Invalid file type, handle accordingly (e.g., show an error message)
                    return BadRequest("Invalid file type. Only PDF and image files are allowed.");
                }

                using (var stream = new FileStream(fileToWrite, FileMode.Create))
                {
                    model.Document.CopyTo(stream);
                }

                var customerDocument = new CustomerDocument
                {
                    CustomerId = model.CustomerId,
                    CustomerName = HttpContext.Session.GetString(SessionCustomerName),
                    AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
                    TinNumber = model.TinNumber,
                    AssesmentYear = model.AssesmentYear,
                    Reference = model.Reference,
                    RefNumber = model.RefNumber,
                    Document = newFilePath,
                    DocumentPath = newFilePath
                };

                _context.CustomerDocuments.Add(customerDocument);
                _context.SaveChanges();

                return RedirectToAction("ViewDocuments");
            }

            // No file uploaded, handle accordingly (e.g., show an error message)
            return BadRequest("No file uploaded.");
        }



        //=====================**********************************************************
        //pdf and image validation with size

        //[HttpPost]
        //public IActionResult AddDocument(VMCustomerDocument model)
        //{
        //    // Check if a file is uploaded
        //    if (model.Document != null && model.Document.Length > 0)
        //    {
        //        string webRoot = environment.WebRootPath;
        //        string folder = "Documents"; // Change the folder name as per your requirement

        //        // Generate a unique file name
        //        string fileName = Guid.NewGuid().ToString();

        //        // Get the file extension
        //        string fileExtension = Path.GetExtension(model.Document.FileName);

        //        // Determine the file path based on the file extension
        //        string fileToWrite;
        //        string newFilePath;

        //        if (fileExtension.ToLower() == ".pdf")
        //        {
        //            // Check PDF file size (200 KB limit)
        //            if (model.Document.Length > 200 * 1024)
        //            {
        //                return BadRequest("Invalid file size. PDF files should be up to 200 KB.");
        //            }

        //            fileToWrite = Path.Combine(webRoot, folder, fileName + fileExtension);
        //            newFilePath = Path.Combine(folder, fileName + fileExtension);
        //        }
        //        else if (IsImageFileExtension(fileExtension.ToLower()))
        //        {
        //            // Check image file size (100 KB limit)
        //            if (model.Document.Length > 100 * 1024)
        //            {
        //                return BadRequest("Invalid file size. Image files should be up to 100 KB.");
        //            }

        //            fileToWrite = Path.Combine(webRoot, folder, "Images", fileName + fileExtension);
        //            newFilePath = Path.Combine("Images", fileName + fileExtension);
        //        }
        //        else
        //        {
        //            // Invalid file type, handle accordingly (e.g., show an error message)
        //            return BadRequest("Invalid file type. Only PDF and image files are allowed.");
        //        }

        //        using (var stream = new FileStream(fileToWrite, FileMode.Create))
        //        {
        //            model.Document.CopyTo(stream);
        //        }

        //        var customerDocument = new CustomerDocument
        //        {
        //            CustomerId = model.CustomerId,
        //            CustomerName = HttpContext.Session.GetString(SessionCustomerName),
        //            AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
        //            TinNumber = model.TinNumber,
        //            AssesmentYear = model.AssesmentYear,
        //            Reference = model.Reference,
        //            RefNumber = model.RefNumber,
        //            Document = newFilePath,
        //            DocumentPath = newFilePath
        //        };

        //        _context.CustomerDocuments.Add(customerDocument);
        //        _context.SaveChanges();

        //        return RedirectToAction("ViewDocuments");
        //    }

        //    // No file uploaded, handle accordingly (e.g., show an error message)
        //    return BadRequest("No file uploaded.");
        //}
        //=============================================================================
        private bool IsImageFileExtension(string fileExtension)
        {
            string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif" }; // Add more image file extensions if needed

            return imageExtensions.Contains(fileExtension);
        }


        //==================================================================================
        //ok pdf and image save
        //[HttpPost]
        //public IActionResult AddDocument(VMCustomerDocument model)
        //{
        //    // Check if a file is uploaded
        //    if (model.Document != null && model.Document.Length > 0)
        //    {
        //        string webRoot = environment.WebRootPath;
        //        string folder = "Images"; // Change the folder name as per your requirement

        //        // Generate a unique file name
        //        string fileName = Guid.NewGuid().ToString();

        //        // Get the file extension
        //        string fileExtension = Path.GetExtension(model.Document.FileName);

        //        // Determine the file path based on the file extension
        //        string fileToWrite;
        //        string newFilePath;

        //        if (fileExtension.ToLower() == ".pdf")
        //        {
        //            fileToWrite = Path.Combine(webRoot, folder, fileName + fileExtension);
        //            newFilePath = Path.Combine(folder, fileName + fileExtension);
        //        }
        //        else if (IsImageFileExtension(fileExtension.ToLower()))
        //        {
        //            fileToWrite = Path.Combine(webRoot, folder, "Images", fileName + fileExtension);
        //            newFilePath = Path.Combine("Images", fileName + fileExtension);
        //        }
        //        else
        //        {
        //            // Invalid file type, handle accordingly (e.g., show an error message)
        //            return BadRequest("Invalid file type. Only PDF and image files are allowed.");
        //        }

        //        using (var stream = new FileStream(fileToWrite, FileMode.Create))
        //        {
        //            model.Document.CopyTo(stream);
        //        }

        //        var customerDocument = new CustomerDocument
        //        {
        //            CustomerId = model.CustomerId,
        //            CustomerName = HttpContext.Session.GetString(SessionCustomerName),
        //            AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
        //            TinNumber = model.TinNumber,
        //            AssesmentYear = model.AssesmentYear,
        //            Reference = model.Reference,
        //            RefNumber = model.RefNumber,
        //            Document = newFilePath,
        //            DocumentPath = newFilePath
        //        };

        //        _context.CustomerDocuments.Add(customerDocument);
        //        _context.SaveChanges();

        //        return RedirectToAction("ViewDocuments");
        //    }

        //    // No file uploaded, handle accordingly (e.g., show an error message)
        //    return BadRequest("No file uploaded.");
        //}

        //private bool IsImageFileExtension(string fileExtension)
        //{
        //    string[] imageExtensions = { ".jpg", ".jpeg", ".png", ".gif" }; // Add more image file extensions if needed

        //    return imageExtensions.Contains(fileExtension);
        //}

        //=====================================================================
    }
        //ok file save important-documents.jpg
        //[HttpPost]
        //public IActionResult AddDocument(VMCustomerDocument model)
        //{
        //    //image
        //    string webroot = environment.WebRootPath;
        //    string folder = "Images";
        //    string imageFileName = Path.GetFileName(model.Document.FileName);
        //    string fileToWrite = Path.Combine(webroot, folder, imageFileName);
        //    string newFilePath = Path.Combine("Images", imageFileName);

        //    //var newFilePath = Path.Combine(Server.MapPath("~/Images"), imageFileName);

        //    //if (ModelState.IsValid)
        //    //{
        //    using (var steam = new FileStream(fileToWrite, FileMode.Create))
        //    {
        //        model.Document.CopyTo(steam);

        //    }

        //    //if (ModelState.IsValid)
        //    //{
        //    var customerDocument = new CustomerDocument
        //    {
        //        CustomerId = model.CustomerId,
        //        CustomerName = HttpContext.Session.GetString(SessionCustomerName),
        //        AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
        //        TinNumber = model.TinNumber,
        //        AssesmentYear = model.AssesmentYear,
        //        Reference = model.Reference,
        //        RefNumber = model.RefNumber,
        //        Document=newFilePath,
        //        DocumentPath = newFilePath
        //    };


        //        _context.CustomerDocuments.Add(customerDocument);
        //        _context.SaveChanges();

        //        //return View();
        //        return RedirectToAction("ViewDocuments");
        //    }

        //}
        //=============================================================================


        //ok with file path==========================================413ab614-2a42-43ac-8f2f-6a61a0c9ce8d_Microsoft.AspNetCore.Http
        //[HttpPost]
        //public IActionResult AddDocument(VMCustomerDocument model, IFormFile file)
        //{
        //    //if (ModelState.IsValid)
        //    //{
        //    var customerDocument = new CustomerDocument
        //    {
        //        CustomerId = model.CustomerId,
        //        CustomerName = HttpContext.Session.GetString(SessionCustomerName),
        //        AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
        //        TinNumber = model.TinNumber,
        //        AssesmentYear = model.AssesmentYear,
        //        Reference = model.Reference,
        //        RefNumber = model.RefNumber
        //    };
        //    if (model.Document != null)
        //    {
        //        string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");
        //        string uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Document;
        //        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

        //        using (FileStream fileStream = new FileStream(filePath, FileMode.Create))
        //        {
        //            model.Document.CopyTo(fileStream);
        //        }

        //        customerDocument.DocumentPath = uniqueFileName; // Set the DocumentPath property to the file name

        //        _context.CustomerDocuments.Add(customerDocument);
        //        _context.SaveChanges();

        //        //return View();
        //        return RedirectToAction("ViewDocuments");
        //    }
        //    else
        //    {
        //        return RedirectToAction("ViewDocuments");
        //    }
        //}
        //========
        //else
        //{
        //    // Return an error response if the customer is not found
        //    return View();
        //}
    }


//URL Path OK
//[HttpPost]
//public IActionResult AddDocument(VMCustomerDocument model)
//{
//    //if (ModelState.IsValid)
//    //{
//    if (model.Document != null && model.Document.Length > 0)
//    {
//        string uploadsFolder = Path.Combine(environment.WebRootPath, "Images");

//        string uniqueFileName = Guid.NewGuid().ToString() + "_" + model.Document.FileName;
//        string filePath = Path.Combine(uploadsFolder, uniqueFileName);

//        using (var fileStream = new FileStream(filePath, FileMode.Create))
//        {
//            model.Document.CopyTo(fileStream);
//        }

//        var customerDocument = new CustomerDocument
//        {
//            CustomerId = model.CustomerId,
//            CustomerName = HttpContext.Session.GetString(SessionCustomerName),
//            AccountNumber = HttpContext.Session.GetString(SessionAccountNo),
//            TinNumber = model.TinNumber,
//            AssesmentYear = model.AssesmentYear,
//            DocumentPath = filePath,
//            Reference = model.Reference,
//            RefNumber = model.RefNumber
//        };

//        _context.CustomerDocuments.Add(customerDocument);
//        _context.SaveChanges();

//        //return View();
//        return RedirectToAction("ViewDocuments");
//    }
//    else
//    {
//        return View();
//    }
//    //}

//    //// If the model state is not valid or the document is not provided, return to the view with errors
//    //return View(model);
//}





