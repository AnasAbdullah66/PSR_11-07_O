﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PSR_Add_Document.Models;
using static System.Net.WebRequestMethods;

namespace PSR_Add_Document.Controllers
{
    public class OtpManageController : Controller
    {
        private readonly CustomerDbContext _context;

        public OtpManageController(CustomerDbContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            var otpList = await _context.OTPManage.ToListAsync();
            return View(otpList);
        }

        // GET: OTP/Create
        public IActionResult Create()
        {
            return View();
        }

        
        // POST: OTPManage/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(OTPManage otp)
        {
            if (ModelState.IsValid)
            {
                OTPManage otpM=new OTPManage();
                otpM.OtpTime = DateTime.Now;
                otpM.MobileNumber = otp.MobileNumber;
                otpM.CustomerId = otp.CustomerId;
                otpM.OTP=GenerateOTP();

                _context.Add(otpM);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
                //_context.Add(otp);
                //await _context.SaveChangesAsync();
                //return RedirectToAction(nameof(Index));
            }

            ViewBag.CustomerId = new SelectList(_context.Customers, "CustomerId", "FullName", otp.CustomerId);

            return View(otp);
        }

        public string GenerateOTP()
        {
            string[] arr = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "0" };
            string IDString = "";
            string temp;
            var NewPassword = "";
            Random rand = new Random();
            for (int i = 0; i < 4; i++)
            {
                temp = arr[rand.Next(0, arr.Length)];
                IDString += temp;
                NewPassword = IDString;
            }
            return NewPassword;
        }

        // Example usage
        public IActionResult GenerateAndDisplayOTP()
        {
            string otp = GenerateOTP();
            ViewBag.OTP = otp;
            return View();
        }

        


    }
}
