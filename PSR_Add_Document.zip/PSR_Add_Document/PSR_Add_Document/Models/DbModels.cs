﻿using Microsoft.EntityFrameworkCore;
using System.Reflection;
using PSR_Add_Document.Models;
using System.ComponentModel.DataAnnotations;

namespace PSR_Add_Document.Models
{
    public class Customer
    {
        public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string AccountNumber { get; set; }
        public string Address { get; set; }
        public string MobileNumber { get; set; }
        //public string? TinNumber { get; set; }
        public int Gender { get; set; }
        public string Brn { get; set; }
        [DataType(DataType.EmailAddress)]
        public string? Email { get; set; }
        public DateTime DOB { get; set; }
    }

    public class CustomerDbContext : DbContext
    {
        public CustomerDbContext(DbContextOptions<CustomerDbContext> options) : base(options)
        {

        }

        public DbSet<Customer> Customers { get; set; }
        public DbSet<OtpVerificationOptions> OtpVerificationOptions { get; set; }
        public DbSet<PSR_Add_Document.Models.OTPManage>? OTPManage { get; set; }
        public DbSet<CustomerDocument> CustomerDocuments { get; set; }
        //public DbSet<SubUser> SubUsers { get; set; }
    }
}
